# AI Stock Master currently uses a local WebView UI and needs no custom rules.
