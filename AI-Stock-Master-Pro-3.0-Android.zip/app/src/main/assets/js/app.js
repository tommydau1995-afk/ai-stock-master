const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={symbol:"VNINDEX",days:90,rows:[],indicators:{},quotes:{},newsLoaded:false};
const pending=new Map();
const store={
  get:(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},
  set:(key,value)=>localStorage.setItem(key,JSON.stringify(value))
};
let watch=store.get("watchlist",["FPT","MBB","HPG","VNM"]);
let portfolio=store.get("portfolio",[]);
let alerts=store.get("alerts",[]);

window.onNativeResult=(id,json)=>{
  const task=pending.get(id); if(!task)return;
  pending.delete(id); let value; try{value=JSON.parse(json)}catch{value={ok:false,error:"Phản hồi không hợp lệ"}}
  value.ok?task.resolve(value):task.reject(new Error(value.error||"Không thể tải dữ liệu"));
};
function native(method,...args){
  return new Promise((resolve,reject)=>{
    if(!window.NativeApp||typeof NativeApp[method]!=="function") return reject(new Error("Chức năng này chỉ hoạt động trong ứng dụng Android"));
    const id=Date.now()+"_"+Math.random().toString(36).slice(2); pending.set(id,{resolve,reject});
    NativeApp[method](...args,id);
    setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error("Kết nối quá thời gian"))}},65000);
  });
}
const fmt=(v,d=2)=>Number(v||0).toLocaleString("vi-VN",{minimumFractionDigits:d,maximumFractionDigits:d});
const money=v=>`${Math.round(v*1000).toLocaleString("vi-VN")} ₫`;
function toast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}

function sma(values,n){if(values.length<n)return null;return values.slice(-n).reduce((a,b)=>a+b,0)/n}
function emaSeries(values,n){const k=2/(n+1);let e=values[0];return values.map(v=>e=v*k+e*(1-k))}
function rsi(values,n=14){
  if(values.length<=n)return null;let gains=0,losses=0;
  for(let i=values.length-n;i<values.length;i++){const d=values[i]-values[i-1];d>0?gains+=d:losses-=d}
  if(!losses)return 100;return 100-(100/(1+gains/losses));
}
function calculate(rows){
  const closes=rows.map(r=>+r.close), highs=rows.map(r=>+r.high), lows=rows.map(r=>+r.low);
  const e12=emaSeries(closes,12),e26=emaSeries(closes,26),macd=e12.at(-1)-e26.at(-1);
  const macdLine=e12.map((v,i)=>v-e26[i]),signal=emaSeries(macdLine,9).at(-1);
  return{rsi:rsi(closes),ma20:sma(closes,20),ma50:sma(closes,50),macd,signal,
    support:Math.min(...lows.slice(-20)),resistance:Math.max(...highs.slice(-20)),volume:sma(rows.map(r=>+r.nmVolume||0),20)};
}
function normalize(payload){
  return (payload?.data||[]).map(r=>({date:r.date,open:+(r.adOpen||r.open),high:+(r.adHigh||r.high),low:+(r.adLow||r.low),close:+(r.adClose||r.close),nmVolume:+r.nmVolume||0,change:+r.change||0,pctChange:+r.pctChange||0})).filter(r=>r.date&&r.close>0).sort((a,b)=>a.date.localeCompare(b.date));
}
async function loadMarket(symbol=state.symbol,days=state.days,quiet=false){
  symbol=symbol.toUpperCase().trim().replace(/[^A-Z0-9]/g,"");if(!symbol)return;
  if(!quiet){$("#dataStatus").textContent=`Đang tải ${symbol} từ VNDIRECT…`;$("#chartEmpty").style.display="grid"}
  try{
    const result=await native("fetchMarket",symbol,days);
    const rows=normalize(result.payload);if(!rows.length)throw new Error(`Không tìm thấy dữ liệu ${symbol}`);
    state.symbol=symbol;state.days=days;state.rows=rows;state.indicators=calculate(rows);state.quotes[symbol]=rows.at(-1);
    renderMarket();if(!quiet)toast(`Đã cập nhật ${symbol}`);
    return rows.at(-1);
  }catch(e){const message="Không thể tải dữ liệu. Hãy kiểm tra mạng và bấm nút làm mới.";$("#dataStatus").textContent=message;$("#chartEmpty").textContent=message;$("#chartEmpty").style.display="grid";throw e}
}
function renderMarket(){
  const row=state.rows.at(-1),prev=state.rows.at(-2)||row,change=row.close-prev.close,pct=prev.close?change/prev.close*100:0;
  $("#heroSymbol").textContent=state.symbol;$("#heroPrice").textContent=fmt(row.close);
  $("#heroChange").textContent=`${change>=0?"+":""}${fmt(change)} · ${pct>=0?"+":""}${fmt(pct)}%`;
  $("#heroChange").className=change>=0?"up":"down";$("#updatedAt").textContent=`Phiên ${row.date}`;
  $("#dataStatus").textContent=`Nguồn VNDIRECT · ${state.rows.length} phiên`;
  const i=state.indicators,signal=i.rsi>70?"Quá mua":i.rsi<30?"Quá bán":"Trung tính";
  $("#indicators").innerHTML=[
    ["RSI (14)",fmt(i.rsi,1),signal,i.rsi>70||i.rsi<30?"down":"up"],
    ["MACD",fmt(i.macd,2),i.macd>i.signal?"Tích cực":"Tiêu cực",i.macd>i.signal?"up":"down"],
    ["MA20",fmt(i.ma20),row.close>i.ma20?"Trên MA20":"Dưới MA20",row.close>i.ma20?"up":"down"],
    ["MA50",fmt(i.ma50),row.close>i.ma50?"Trên MA50":"Dưới MA50",row.close>i.ma50?"up":"down"],
    ["Hỗ trợ",fmt(i.support),"20 phiên",""],
    ["Kháng cự",fmt(i.resistance),"20 phiên",""]
  ].map(x=>`<article class="metric"><small>${x[0]}</small><strong>${x[1]}</strong><em class="${x[3]}">${x[2]}</em></article>`).join("");
  const trend=row.close>i.ma20&&i.ma20>i.ma50?"xu hướng tăng":row.close<i.ma20&&i.ma20<i.ma50?"xu hướng giảm":"xu hướng đi ngang/chuyển pha";
  $("#quickInsight").textContent=`${state.symbol} đang ở ${trend}. RSI ${fmt(i.rsi,1)}, MACD ${i.macd>i.signal?"trên":"dưới"} đường tín hiệu. Vùng tham chiếu: hỗ trợ ${fmt(i.support)}, kháng cự ${fmt(i.resistance)}.`;
  $("#aiSymbol").textContent=state.symbol;$("#aiFacts").textContent=`Giá ${fmt(row.close)} · RSI ${fmt(i.rsi,1)} · MA20 ${fmt(i.ma20)} · MA50 ${fmt(i.ma50)} · MACD ${fmt(i.macd,2)}`;
  $("#symbolInput").value=state.symbol;drawCandles(state.rows);renderWatchlist();
}
function drawCandles(allRows){
  const canvas=$("#candleChart"),box=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1;
  canvas.width=box.width*dpr;canvas.height=box.height*dpr;const c=canvas.getContext("2d");c.scale(dpr,dpr);
  const w=box.width,h=box.height,p={l:8,r:48,t:12,b:24},rows=allRows.slice(-60);
  const min=Math.min(...rows.map(r=>r.low)),max=Math.max(...rows.map(r=>r.high)),range=max-min||1;
  const y=v=>p.t+(max-v)/range*(h-p.t-p.b),step=(w-p.l-p.r)/rows.length;
  c.clearRect(0,0,w,h);c.strokeStyle="#1f3550";c.lineWidth=.7;c.fillStyle="#8ca0bb";c.font="9px system-ui";
  for(let j=0;j<5;j++){const yy=p.t+j*(h-p.t-p.b)/4;c.beginPath();c.moveTo(p.l,yy);c.lineTo(w-p.r,yy);c.stroke();c.fillText(fmt(max-j*range/4,1),w-p.r+5,yy+3)}
  rows.forEach((r,i)=>{const x=p.l+(i+.5)*step,up=r.close>=r.open;c.strokeStyle=c.fillStyle=up?"#28d49c":"#ff6376";c.beginPath();c.moveTo(x,y(r.high));c.lineTo(x,y(r.low));c.stroke();const top=y(Math.max(r.open,r.close)),bottom=y(Math.min(r.open,r.close));c.fillRect(x-Math.max(1,step*.28),top,Math.max(2,step*.56),Math.max(1,bottom-top))});
  $("#chartEmpty").style.display="none";
}
function renderWatchlist(){
  $("#watchlist").innerHTML=watch.map(code=>{const q=state.quotes[code];return `<article class="stock" data-code="${code}"><div><h4>${code}</h4><p>${code===state.symbol?"Đang xem":"Chạm để tải biểu đồ"}</p></div><div class="price"><b>${q?fmt(q.close):"--"}</b><small>${q?`Phiên ${q.date}`:"Chưa tải"}</small></div></article>`}).join("");
}
async function refreshWatch(){
  for(const code of watch.slice(0,8)){try{const q=await loadMarket(code,45,true);state.quotes[code]=q}catch{}}
  await loadMarket(state.symbol,state.days,true);renderPortfolio();
}

function renderPortfolio(){
  let total=0,cost=0;
  $("#portfolioList").innerHTML=portfolio.length?portfolio.map((p,index)=>{const q=state.quotes[p.symbol],price=q?.close||p.cost,value=price*p.qty,pnl=(price-p.cost)*p.qty;total+=value;cost+=p.cost*p.qty;return `<article class="list-card"><div><h4>${p.symbol} · ${p.qty.toLocaleString("vi-VN")} CP</h4><p>Giá vốn ${fmt(p.cost)} · Hiện tại ${fmt(price)} · <span class="${pnl>=0?"up":"down"}">${pnl>=0?"+":""}${money(pnl)}</span></p></div><button class="delete" data-remove-pf="${index}">Xóa</button></article>`}).join(""):`<div class="loading">Chưa có cổ phiếu. Hãy thêm mã đầu tiên.</div>`;
  $("#portfolioValue").textContent=money(total);const pnl=total-cost;$("#portfolioPnl").textContent=portfolio.length?`${pnl>=0?"+":""}${money(pnl)} (${cost?fmt(pnl/cost*100):0}%)`:"Chưa có cổ phiếu";$("#portfolioPnl").className=pnl>=0?"up":"down";
}
function renderAlerts(){
  $("#alertList").innerHTML=alerts.length?alerts.map((a,index)=>`<article class="list-card"><div><h4>${a.symbol} ${a.type==="above"?"≥":"≤"} ${fmt(a.target)}</h4><p>Kiểm tra nền · ${a.enabled?"Đang bật":"Đã tắt"}</p></div><div><input class="toggle" type="checkbox" data-toggle-alert="${index}" ${a.enabled?"checked":""}> <button class="delete" data-remove-alert="${index}">Xóa</button></div></article>`).join(""):`<div class="loading">Chưa có cảnh báo giá.</div>`;
  store.set("alerts",alerts);if(window.NativeApp)NativeApp.saveAlerts(JSON.stringify(alerts));
}
async function loadNews(){
  if(state.newsLoaded)return;try{const r=await native("fetchNews");state.newsLoaded=true;$("#newsSource").textContent=`Nguồn: ${r.source} · cập nhật trực tuyến`;$("#newsList").innerHTML=r.items.map(n=>`<article class="list-card news-card" data-url="${encodeURI(n.link||"")}"><h4>${n.title||"Tin mới"}</h4><p>${n.description||""}</p><small>${n.date||"Mới cập nhật"} · Mở bài viết ↗</small></article>`).join("")}catch(e){$("#newsList").innerHTML=`<div class="loading">Không tải được tin: ${e.message}</div>`}}
async function askAi(){
  if(!state.rows.length)return toast("Hãy tải dữ liệu cổ phiếu trước");
  const q=$("#aiQuestion").value.trim()||`Phân tích xu hướng và rủi ro của ${state.symbol}`;
  $("#aiAnswer").classList.add("loading");$("#aiAnswer").textContent="AI đang phân tích dữ liệu thật…";$("#askAi").disabled=true;
  try{
    const last=state.rows.slice(-30),body=JSON.stringify({symbol:state.symbol,question:q,market:{latest:last.at(-1),last30:last},indicators:state.indicators});
    const r=await native("analyze",body);if(r.payload.error)throw new Error(r.payload.detail||r.payload.error);
    $("#aiAnswer").textContent=r.payload.analysis;
  }catch(e){$("#aiAnswer").textContent=`Không thể phân tích AI: ${e.message}\n\nBạn vẫn có thể xem chỉ báo kỹ thuật được tính trực tiếp từ dữ liệu giá thật.`}
  finally{$("#aiAnswer").classList.remove("loading");$("#askAi").disabled=false}
}

$("#loadSymbol").onclick=()=>loadMarket($("#symbolInput").value,state.days).catch(()=>{});
$("#symbolInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("#loadSymbol").click()});
$("#refresh").onclick=()=>loadMarket(state.symbol,state.days).then(()=>{state.newsLoaded=false;if($("#newsScreen").classList.contains("active"))loadNews()}).catch(()=>{});
$$(".periods button").forEach(b=>b.onclick=()=>{$$(".periods button").forEach(x=>x.classList.remove("active"));b.classList.add("active");loadMarket(state.symbol,+b.dataset.days).catch(()=>{})});
$("#watchlist").onclick=e=>{const row=e.target.closest(".stock");if(row)loadMarket(row.dataset.code,state.days).catch(()=>{})};
$("#addWatch").onclick=()=>$("#modal").classList.remove("hidden");$("#closeModal").onclick=()=>$("#modal").classList.add("hidden");
$("#confirmWatch").onclick=()=>{const code=$("#watchSymbol").value.toUpperCase().trim().replace(/[^A-Z0-9]/g,"");if(code&&!watch.includes(code)){watch.push(code);store.set("watchlist",watch);renderWatchlist()}$("#modal").classList.add("hidden");$("#watchSymbol").value=""};
$("#portfolioForm").onsubmit=e=>{e.preventDefault();const symbol=$("#pfSymbol").value.toUpperCase().trim().replace(/[^A-Z0-9]/g,""),qty=+$("#pfQty").value,cost=+$("#pfCost").value;if(symbol&&qty>0&&cost>=0){portfolio.push({symbol,qty,cost});store.set("portfolio",portfolio);if(!watch.includes(symbol)){watch.push(symbol);store.set("watchlist",watch)}renderPortfolio();e.target.reset();toast(`Đã thêm ${symbol}`)}};
$("#portfolioList").onclick=e=>{const i=e.target.dataset.removePf;if(i!==undefined){portfolio.splice(+i,1);store.set("portfolio",portfolio);renderPortfolio()}};
$("#alertForm").onsubmit=e=>{e.preventDefault();const symbol=$("#alertSymbol").value.toUpperCase().trim().replace(/[^A-Z0-9]/g,""),target=+$("#alertTarget").value,type=$("#alertType").value;if(symbol&&target>0){alerts.push({symbol,target,type,enabled:true});renderAlerts();e.target.reset();toast("Đã tạo cảnh báo nền")}};
$("#alertList").onchange=e=>{const i=e.target.dataset.toggleAlert;if(i!==undefined){alerts[+i].enabled=e.target.checked;renderAlerts()}};
$("#alertList").onclick=e=>{const i=e.target.dataset.removeAlert;if(i!==undefined){alerts.splice(+i,1);renderAlerts()}};
$("#newsList").onclick=e=>{const card=e.target.closest("[data-url]");if(card&&window.NativeApp)NativeApp.openUrl(decodeURI(card.dataset.url))};
$("#askAi").onclick=askAi;
$$("nav button").forEach(b=>b.onclick=()=>{$$("nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");$$(".screen").forEach(x=>x.classList.remove("active"));$("#"+b.dataset.screen).classList.add("active");if(b.dataset.screen==="newsScreen")loadNews();if(b.dataset.screen==="portfolioScreen")renderPortfolio();scrollTo(0,0)});
addEventListener("resize",()=>state.rows.length&&drawCandles(state.rows));

renderWatchlist();renderPortfolio();renderAlerts();loadMarket(state.symbol,state.days).catch(()=>{});
