const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={symbol:"VNINDEX",days:90,rows:[],indicators:{},quotes:{},newsLoaded:false};
const pending=new Map();
const store={
  get:(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}},
  set:(key,value)=>localStorage.setItem(key,JSON.stringify(value))
};
let watch=store.get("watchlist",["FPT","MBB","HPG","VNM"]);
let portfolio=store.get("portfolio",[]);
let alerts=store.get("alerts",[]);

window.onNativeResult=(id,json)=>{
  const task=pending.get(id); if(!task)return;
  pending.delete(id); let value; try{value=JSON.parse(json)}catch{value={ok:false,error:"Phản hồi không hợp lệ"}}
  value.ok?task.resolve(value):task.reject(new Error(value.error||"Không thể tải dữ liệu"));
};
function native(method,...args){
  return new Promise((resolve,reject)=>{
    if(!window.NativeApp||typeof NativeApp[method]!=="function") return reject(new Error("Chức năng này chỉ hoạt động trong ứng dụng Android"));
    const id=Date.now()+"_"+Math.random().toString(36).slice(2); pending.set(id,{resolve,reject});
    NativeApp[method](...args,id);
    setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error("Kết nối quá thời gian"))}},65000);
  });
}
const fmt=(v,d=2)=>Number(v||0).toLocaleString("vi-VN",{minimumFractionDigits:d,maximumFractionDigits:d});
const money=v=>`${Math.round(v*1000).toLocaleString("vi-VN")} ₫`;
const compact=v=>Number(v||0).toLocaleString("vi-VN",{maximumFractionDigits:0});
function toast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}

function sma(values,n){if(values.length<n)return null;return values.slice(-n).reduce((a,b)=>a+b,0)/n}
function emaSeries(values,n){const k=2/(n+1);let e=values[0];return values.map(v=>e=v*k+e*(1-k))}
function rsi(values,n=14){
  if(values.length<=n)return null;let gains=0,losses=0;
  for(let i=values.length-n;i<values.length;i++){const d=values[i]-values[i-1];d>0?gains+=d:losses-=d}
  if(!losses)return 100;return 100-(100/(1+gains/losses));
}
function calculate(rows){
  const closes=rows.map(r=>+r.close), highs=rows.map(r=>+r.high), lows=rows.map(r=>+r.low);
  const e12=emaSeries(closes,12),e26=emaSeries(closes,26),macd=e12.at(-1)-e26.at(-1);
  const macdLine=e12.map((v,i)=>v-e26[i]),signal=emaSeries(macdLine,9).at(-1);
  return{rsi:rsi(closes),ma20:sma(closes,20),ma50:sma(closes,50),macd,signal,
    support:Math.min(...lows.slice(-20)),resistance:Math.max(...highs.slice(-20)),volume:sma(rows.map(r=>+r.nmVolume||0),20)};
}
const pctMove=(from,to)=>from?(to/from-1)*100:0;
function buildTradeReport(){
  if(!state.rows.length)return;
  const rows=state.rows,row=rows.at(-1),i=state.indicators,closes=rows.map(x=>x.close);
  const last20=rows.slice(-20),last60=rows.slice(-60),year=rows.slice(-250);
  const high52=Math.max(...year.map(x=>x.high)),low52=Math.min(...year.map(x=>x.low));
  const high60=Math.max(...last60.map(x=>x.high)),low60=Math.min(...last60.map(x=>x.low));
  const avgVol=i.volume||1,volRatio=row.nmVolume/avgVol;
  const ret20=pctMove(rows.at(-Math.min(21,rows.length))?.close,row.close);
  const ret60=pctMove(rows.at(-Math.min(61,rows.length))?.close,row.close);
  const macdPositive=i.macd>i.signal,above20=row.close>i.ma20,above50=row.close>i.ma50;
  const trend=above20&&above50&&i.ma20>i.ma50?"TĂNG":!above20&&!above50&&i.ma20<i.ma50?"GIẢM":"ĐI NGANG / CHUYỂN PHA";
  let technical=0;
  technical+=above20?9:2;technical+=above50?9:2;technical+=i.ma20>i.ma50?7:2;
  technical+=macdPositive?6:2;technical+=i.rsi>=45&&i.rsi<=65?4:i.rsi<30?2:1;
  let flow=volRatio>=1.5?18:volRatio>=1?14:volRatio>=.7?10:6;
  if(row.close>=row.open)flow=Math.min(20,flow+2);
  let momentum=0;momentum+=ret20>5?8:ret20>0?6:ret20>-5?3:1;momentum+=ret60>10?7:ret60>0?5:ret60>-10?3:1;
  let risk=0;const supportGap=pctMove(i.support,row.close),resistanceGap=pctMove(row.close,i.resistance);
  risk+=supportGap>=5?8:supportGap>=2?6:3;risk+=resistanceGap>=8?7:resistanceGap>=4?5:2;
  risk+=i.rsi>75||i.rsi<25?1:i.rsi>70||i.rsi<30?3:5;
  const rawScore=technical+flow+momentum+risk;
  const score=Math.max(0,Math.min(100,Math.round(rawScore/90*100)));
  const verdict=score>=75?"TÍCH CỰC":score>=60?"THEO DÕI MUA":score>=45?"THẬN TRỌNG":"RỦI RO CAO";
  const icon=score>=75?"🟢":score>=60?"🔵":score>=45?"🟠":"🔴";
  const stop=Math.min(i.support,row.close*.93),target1=i.resistance,target2=Math.max(i.resistance,row.close+(row.close-stop)*2);
  const watchLow=Math.min(i.support,i.ma20),watchHigh=Math.max(i.support,i.ma20);
  const rsiText=i.rsi>=70?"quá mua":i.rsi<=30?"quá bán":i.rsi>=55?"tích cực":"trung tính/yếu";
  const volumeText=volRatio>=1.5?"dòng tiền tăng mạnh":volRatio>=1?"thanh khoản cao hơn trung bình":volRatio>=.7?"thanh khoản trung bình thấp":"dòng tiền suy yếu";
  const action=score>=75?"Có thể xem xét mua thăm dò khi giá giữ trên MA20; không mua đuổi ở phiên tăng nóng.":score>=60?"Đưa vào danh sách theo dõi, chỉ giải ngân từng phần khi có nến xác nhận kèm khối lượng.":score>=45?"Ưu tiên quan sát; chờ giá vượt kháng cự hoặc tạo đáy rõ ràng trước khi giải ngân.":"Không mở vị thế mới; người đang nắm giữ cần quản trị tỷ trọng và điểm cắt lỗ.";
  $("#tradeReport").innerHTML=`
    <section class="score-card">
      <small>🏆 TRADE SCORE · ${state.symbol} · PHIÊN ${row.date}</small>
      <div class="score-line"><strong>${score}/100</strong><span class="score-badge">${icon} ${verdict}</span></div>
      <div class="score-bar"><i style="width:${score}%"></i></div>
    </section>
    <section class="report-section">
      <h3>📈 KỸ THUẬT (${technical}/35)</h3>
      <p><b>Xu hướng:</b> ${trend}. Giá ${above20?"trên":"dưới"} MA20 (${fmt(i.ma20)}) và ${above50?"trên":"dưới"} MA50 (${fmt(i.ma50)}).</p>
      <p><b>Động lượng:</b> RSI(14) ${fmt(i.rsi,1)} — ${rsiText}; MACD ${macdPositive?"trên":"dưới"} signal (${fmt(i.macd,2)} / ${fmt(i.signal,2)}).</p>
      <p><b>Hiệu suất:</b> 20 phiên ${ret20>=0?"+":""}${fmt(ret20,1)}%; 60 phiên ${ret60>=0?"+":""}${fmt(ret60,1)}%.</p>
      <div class="report-grid">
        <div><small>HỖ TRỢ 20 PHIÊN</small><strong>${fmt(i.support)}</strong></div>
        <div><small>KHÁNG CỰ 20 PHIÊN</small><strong>${fmt(i.resistance)}</strong></div>
        <div><small>ĐÁY 52 TUẦN*</small><strong>${fmt(low52)}</strong></div>
        <div><small>ĐỈNH 52 TUẦN*</small><strong>${fmt(high52)}</strong></div>
      </div>
      <p class="source">*Trong tối đa ${year.length} phiên dữ liệu ứng dụng tải được. Nguồn giá: VNDIRECT.</p>
    </section>
    <section class="report-section">
      <h3>💧 DÒNG TIỀN (${flow}/20)</h3>
      <p>Khối lượng phiên gần nhất <b>${compact(row.nmVolume)}</b>, bằng <b>${fmt(volRatio,2)}x</b> trung bình 20 phiên — ${volumeText}.</p>
      <p>Biên 60 phiên: ${fmt(low60)}–${fmt(high60)}. Giá hiện ở ${fmt((row.close-low60)/(high60-low60||1)*100,0)}% vùng dao động này.</p>
    </section>
    <section class="report-section">
      <h3>🌐 ĐỘNG LƯỢNG THỊ TRƯỜNG (${momentum}/15)</h3>
      <p>Điểm được tính từ sức mạnh giá 20 và 60 phiên của chính ${state.symbol}. So sánh tương quan với VN-Index sẽ được bổ sung khi tải đồng thời dữ liệu chỉ số.</p>
    </section>
    <section class="report-section fundamental-note">
      <h3>📋 CƠ BẢN — CHƯA CHẤM ĐIỂM</h3>
      <p>P/E, P/B, ROE, doanh thu, lợi nhuận và nợ vay chưa có nguồn chuẩn hóa trong phiên bản này nên ứng dụng <b>không tự tạo số liệu</b>. Trade Score hiện là điểm giao dịch kỹ thuật, không phải định giá doanh nghiệp.</p>
    </section>
    <section class="report-section">
      <h3>⚠️ RỦI RO (${risk}/20)</h3>
      <p>Khoảng cách tới hỗ trợ: ${fmt(supportGap,1)}%; dư địa tới kháng cự gần: ${fmt(resistanceGap,1)}%. ${i.rsi>70?"RSI cao làm tăng rủi ro mua đuổi.":i.rsi<30?"RSI quá bán có thể xuất hiện nhịp hồi nhưng chưa tự động là tín hiệu mua.":"RSI chưa ở vùng cực đoan."}</p>
    </section>
    <section class="action-plan">
      <h3>🎯 KẾ HOẠCH HÀNH ĐỘNG THAM KHẢO</h3>
      <p>${action}</p>
      <div class="levels">
        <div><small>VÙNG THEO DÕI</small><strong>${fmt(watchLow)}–${fmt(watchHigh)}</strong></div>
        <div><small>CẮT LỖ THAM CHIẾU</small><strong>${fmt(stop)}</strong></div>
        <div><small>MỤC TIÊU 1 / 2</small><strong>${fmt(target1)} / ${fmt(target2)}</strong></div>
      </div>
      <p class="source">Mức giá được tính theo hỗ trợ/kháng cự và tỷ lệ lợi nhuận:rủi ro 2:1; cần điều chỉnh theo giá vốn và khẩu vị rủi ro cá nhân.</p>
    </section>`;
}
function normalize(payload){
  return (payload?.data||[]).map(r=>({date:r.date,open:+(r.adOpen||r.open),high:+(r.adHigh||r.high),low:+(r.adLow||r.low),close:+(r.adClose||r.close),nmVolume:+r.nmVolume||0,change:+r.change||0,pctChange:+r.pctChange||0})).filter(r=>r.date&&r.close>0).sort((a,b)=>a.date.localeCompare(b.date));
}
async function loadMarket(symbol=state.symbol,days=state.days,quiet=false){
  symbol=symbol.toUpperCase().trim().replace(/[^A-Z0-9]/g,"");if(!symbol)return;
  if(!quiet){$("#dataStatus").textContent=`Đang tải ${symbol} từ VNDIRECT…`;$("#chartEmpty").style.display="grid"}
  try{
    const result=await native("fetchMarket",symbol,days);
    const rows=normalize(result.payload);if(!rows.length)throw new Error(`Không tìm thấy dữ liệu ${symbol}`);
    state.symbol=symbol;state.days=days;state.rows=rows;state.indicators=calculate(rows);state.quotes[symbol]=rows.at(-1);
    renderMarket();if(!quiet)toast(`Đã cập nhật ${symbol}`);
    return rows.at(-1);
  }catch(e){const message="Không thể tải dữ liệu. Hãy kiểm tra mạng và bấm nút làm mới.";$("#dataStatus").textContent=message;$("#chartEmpty").textContent=message;$("#chartEmpty").style.display="grid";throw e}
}
function renderMarket(){
  const row=state.rows.at(-1),prev=state.rows.at(-2)||row,change=row.close-prev.close,pct=prev.close?change/prev.close*100:0;
  $("#heroSymbol").textContent=state.symbol;$("#heroPrice").textContent=fmt(row.close);
  $("#heroChange").textContent=`${change>=0?"+":""}${fmt(change)} · ${pct>=0?"+":""}${fmt(pct)}%`;
  $("#heroChange").className=change>=0?"up":"down";$("#updatedAt").textContent=`Phiên ${row.date}`;
  const i=state.indicators,range=row.low?((row.high-row.low)/row.low*100):0;
  const position=i.resistance>i.support?Math.max(0,Math.min(100,(row.close-i.support)/(i.resistance-i.support)*100)):0;
  $("#detailTitle").textContent=`Chi tiết ${state.symbol}`;$("#detailDate").textContent=`Phiên ${row.date}`;
  $("#detailReference").textContent=fmt(prev.close);$("#detailOpen").textContent=fmt(row.open);
  $("#detailHigh").textContent=fmt(row.high);$("#detailLow").textContent=fmt(row.low);
  $("#detailClose").textContent=fmt(row.close);$("#detailVolume").textContent=compact(row.nmVolume);
  $("#detailRange").textContent=`${fmt(range)}%`;$("#detailPosition").textContent=`${fmt(position,0)}% vùng giá`;
  $("#dataStatus").textContent=`Nguồn VNDIRECT · ${state.rows.length} phiên`;
  const signal=i.rsi>70?"Quá mua":i.rsi<30?"Quá bán":"Trung tính";
  $("#indicators").innerHTML=[
    ["RSI (14)",fmt(i.rsi,1),signal,i.rsi>70||i.rsi<30?"down":"up"],
    ["MACD",fmt(i.macd,2),i.macd>i.signal?"Tích cực":"Tiêu cực",i.macd>i.signal?"up":"down"],
    ["MA20",fmt(i.ma20),row.close>i.ma20?"Trên MA20":"Dưới MA20",row.close>i.ma20?"up":"down"],
    ["MA50",fmt(i.ma50),row.close>i.ma50?"Trên MA50":"Dưới MA50",row.close>i.ma50?"up":"down"],
    ["Hỗ trợ",fmt(i.support),"20 phiên",""],
    ["Kháng cự",fmt(i.resistance),"20 phiên",""]
  ].map(x=>`<article class="metric"><small>${x[0]}</small><strong>${x[1]}</strong><em class="${x[3]}">${x[2]}</em></article>`).join("");
  const trend=row.close>i.ma20&&i.ma20>i.ma50?"xu hướng tăng":row.close<i.ma20&&i.ma20<i.ma50?"xu hướng giảm":"xu hướng đi ngang/chuyển pha";
  $("#quickInsight").textContent=`${state.symbol} đang ở ${trend}. RSI ${fmt(i.rsi,1)}, MACD ${i.macd>i.signal?"trên":"dưới"} đường tín hiệu. Vùng tham chiếu: hỗ trợ ${fmt(i.support)}, kháng cự ${fmt(i.resistance)}.`;
  $("#aiSymbol").textContent=state.symbol;$("#aiFacts").textContent=`Giá ${fmt(row.close)} · RSI ${fmt(i.rsi,1)} · MA20 ${fmt(i.ma20)} · MA50 ${fmt(i.ma50)} · MACD ${fmt(i.macd,2)}`;
  $("#symbolInput").value=state.symbol;drawCandles(state.rows);renderWatchlist();buildTradeReport();
}
function drawCandles(allRows){
  const canvas=$("#candleChart"),box=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1;
  canvas.width=box.width*dpr;canvas.height=box.height*dpr;const c=canvas.getContext("2d");c.scale(dpr,dpr);
  const w=box.width,h=box.height,p={l:8,r:48,t:12,b:24},rows=allRows.slice(-60);
  const min=Math.min(...rows.map(r=>r.low)),max=Math.max(...rows.map(r=>r.high)),range=max-min||1;
  const y=v=>p.t+(max-v)/range*(h-p.t-p.b),step=(w-p.l-p.r)/rows.length;
  c.clearRect(0,0,w,h);c.strokeStyle="#1f3550";c.lineWidth=.7;c.fillStyle="#8ca0bb";c.font="9px system-ui";
  for(let j=0;j<5;j++){const yy=p.t+j*(h-p.t-p.b)/4;c.beginPath();c.moveTo(p.l,yy);c.lineTo(w-p.r,yy);c.stroke();c.fillText(fmt(max-j*range/4,1),w-p.r+5,yy+3)}
  rows.forEach((r,i)=>{const x=p.l+(i+.5)*step,up=r.close>=r.open;c.strokeStyle=c.fillStyle=up?"#28d49c":"#ff6376";c.beginPath();c.moveTo(x,y(r.high));c.lineTo(x,y(r.low));c.stroke();const top=y(Math.max(r.open,r.close)),bottom=y(Math.min(r.open,r.close));c.fillRect(x-Math.max(1,step*.28),top,Math.max(2,step*.56),Math.max(1,bottom-top))});
  $("#chartEmpty").style.display="none";
}
function renderWatchlist(){
  $("#watchlist").innerHTML=watch.map(code=>{const q=state.quotes[code],selected=code===state.symbol;return `<article class="stock${selected?" selected":""}" data-code="${code}"><div><h4>${code}</h4><p>${selected?"Đang xem chi tiết":"Chạm để xem đầy đủ số liệu"}</p></div><div class="price"><b>${q?fmt(q.close):"--"}</b><small>${q?`Phiên ${q.date}`:"Chạm để tải"}</small></div></article>`}).join("");
}
async function refreshWatch(){
  for(const code of watch.slice(0,8)){try{const q=await loadMarket(code,45,true);state.quotes[code]=q}catch{}}
  await loadMarket(state.symbol,state.days,true);renderPortfolio();
}

function renderPortfolio(){
  let total=0,cost=0;
  $("#portfolioList").innerHTML=portfolio.length?portfolio.map((p,index)=>{const q=state.quotes[p.symbol],price=q?.close||p.cost,value=price*p.qty,pnl=(price-p.cost)*p.qty;total+=value;cost+=p.cost*p.qty;return `<article class="list-card"><div><h4>${p.symbol} · ${p.qty.toLocaleString("vi-VN")} CP</h4><p>Giá vốn ${fmt(p.cost)} · Hiện tại ${fmt(price)} · <span class="${pnl>=0?"up":"down"}">${pnl>=0?"+":""}${money(pnl)}</span></p></div><button class="delete" data-remove-pf="${index}">Xóa</button></article>`}).join(""):`<div class="loading">Chưa có cổ phiếu. Hãy thêm mã đầu tiên.</div>`;
  $("#portfolioValue").textContent=money(total);const pnl=total-cost;$("#portfolioPnl").textContent=portfolio.length?`${pnl>=0?"+":""}${money(pnl)} (${cost?fmt(pnl/cost*100):0}%)`:"Chưa có cổ phiếu";$("#portfolioPnl").className=pnl>=0?"up":"down";
}
function renderAlerts(){
  $("#alertList").innerHTML=alerts.length?alerts.map((a,index)=>`<article class="list-card"><div><h4>${a.symbol} ${a.type==="above"?"≥":"≤"} ${fmt(a.target)}</h4><p>Kiểm tra nền · ${a.enabled?"Đang bật":"Đã tắt"}</p></div><div><input class="toggle" type="checkbox" data-toggle-alert="${index}" ${a.enabled?"checked":""}> <button class="delete" data-remove-alert="${index}">Xóa</button></div></article>`).join(""):`<div class="loading">Chưa có cảnh báo giá.</div>`;
  store.set("alerts",alerts);if(window.NativeApp)NativeApp.saveAlerts(JSON.stringify(alerts));
}
async function loadNews(){
  if(state.newsLoaded)return;try{const r=await native("fetchNews");state.newsLoaded=true;$("#newsSource").textContent=`Nguồn: ${r.source} · cập nhật trực tuyến`;$("#newsList").innerHTML=r.items.map(n=>`<article class="list-card news-card" data-url="${encodeURI(n.link||"")}"><h4>${n.title||"Tin mới"}</h4><p>${n.description||""}</p><small>${n.date||"Mới cập nhật"} · Mở bài viết ↗</small></article>`).join("")}catch(e){$("#newsList").innerHTML=`<div class="loading">Không tải được tin: ${e.message}</div>`}}
async function askAi(){
  if(!state.rows.length)return toast("Hãy tải dữ liệu cổ phiếu trước");
  const q=$("#aiQuestion").value.trim()||`Phân tích xu hướng và rủi ro của ${state.symbol}`;
  $("#aiAnswer").classList.add("loading");$("#aiAnswer").textContent="AI đang phân tích dữ liệu thật…";$("#askAi").disabled=true;
  try{
    const history=state.rows.slice(-250),body=JSON.stringify({symbol:state.symbol,question:q,market:{latest:history.at(-1),history},indicators:state.indicators,tradeReport:true});
    const r=await native("analyze",body);if(r.payload.error)throw new Error(r.payload.detail||r.payload.error);
    $("#aiAnswer").textContent=r.payload.analysis;
  }catch(e){$("#aiAnswer").textContent=`Không thể phân tích AI: ${e.message}\n\nBạn vẫn có thể xem chỉ báo kỹ thuật được tính trực tiếp từ dữ liệu giá thật.`}
  finally{$("#aiAnswer").classList.remove("loading");$("#askAi").disabled=false}
}

$("#loadSymbol").onclick=()=>loadMarket($("#symbolInput").value,state.days).catch(()=>{});
$("#symbolInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("#loadSymbol").click()});
$("#refresh").onclick=()=>loadMarket(state.symbol,state.days).then(()=>{state.newsLoaded=false;if($("#newsScreen").classList.contains("active"))loadNews()}).catch(()=>{});
$$(".periods button").forEach(b=>b.onclick=()=>{$$(".periods button").forEach(x=>x.classList.remove("active"));b.classList.add("active");loadMarket(state.symbol,+b.dataset.days).catch(()=>{})});
$("#watchlist").onclick=e=>{const row=e.target.closest(".stock");if(row){const code=row.dataset.code;loadMarket(code,state.days).then(()=>{scrollTo({top:0,behavior:"smooth"});toast(`Đang hiển thị đầy đủ số liệu ${code}`)}).catch(()=>{})}};
$("#addWatch").onclick=()=>$("#modal").classList.remove("hidden");$("#closeModal").onclick=()=>$("#modal").classList.add("hidden");
$("#confirmWatch").onclick=()=>{const code=$("#watchSymbol").value.toUpperCase().trim().replace(/[^A-Z0-9]/g,"");if(code&&!watch.includes(code)){watch.push(code);store.set("watchlist",watch);renderWatchlist()}$("#modal").classList.add("hidden");$("#watchSymbol").value=""};
$("#portfolioForm").onsubmit=e=>{e.preventDefault();const symbol=$("#pfSymbol").value.toUpperCase().trim().replace(/[^A-Z0-9]/g,""),qty=+$("#pfQty").value,cost=+$("#pfCost").value;if(symbol&&qty>0&&cost>=0){portfolio.push({symbol,qty,cost});store.set("portfolio",portfolio);if(!watch.includes(symbol)){watch.push(symbol);store.set("watchlist",watch)}renderPortfolio();e.target.reset();toast(`Đã thêm ${symbol}`)}};
$("#portfolioList").onclick=e=>{const i=e.target.dataset.removePf;if(i!==undefined){portfolio.splice(+i,1);store.set("portfolio",portfolio);renderPortfolio()}};
$("#alertForm").onsubmit=e=>{e.preventDefault();const symbol=$("#alertSymbol").value.toUpperCase().trim().replace(/[^A-Z0-9]/g,""),target=+$("#alertTarget").value,type=$("#alertType").value;if(symbol&&target>0){alerts.push({symbol,target,type,enabled:true});renderAlerts();e.target.reset();toast("Đã tạo cảnh báo nền")}};
$("#alertList").onchange=e=>{const i=e.target.dataset.toggleAlert;if(i!==undefined){alerts[+i].enabled=e.target.checked;renderAlerts()}};
$("#alertList").onclick=e=>{const i=e.target.dataset.removeAlert;if(i!==undefined){alerts.splice(+i,1);renderAlerts()}};
$("#newsList").onclick=e=>{const card=e.target.closest("[data-url]");if(card&&window.NativeApp)NativeApp.openUrl(decodeURI(card.dataset.url))};
$("#askAi").onclick=askAi;
$$("nav button").forEach(b=>b.onclick=()=>{$$("nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");$$(".screen").forEach(x=>x.classList.remove("active"));$("#"+b.dataset.screen).classList.add("active");if(b.dataset.screen==="newsScreen")loadNews();if(b.dataset.screen==="portfolioScreen")renderPortfolio();scrollTo(0,0)});
addEventListener("resize",()=>state.rows.length&&drawCandles(state.rows));

renderWatchlist();renderPortfolio();renderAlerts();loadMarket(state.symbol,state.days).catch(()=>{});
