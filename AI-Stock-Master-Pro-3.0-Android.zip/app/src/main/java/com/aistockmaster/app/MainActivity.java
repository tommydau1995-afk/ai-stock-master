package com.aistockmaster.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends ComponentActivity {
    private static final String AI_API = "https://ai-stock-master-api.tommydau1995.chatgpt.site";
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeBridge(this), "NativeApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        scheduleAlerts();
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 50);
        }
    }

    private void scheduleAlerts() {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(PriceAlertWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("stock-price-alerts", ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    private void sendToJs(String id, JSONObject payload) {
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.onNativeResult(" + JSONObject.quote(id) + "," + JSONObject.quote(payload.toString()) + ")", null));
    }

    private class NativeBridge {
        private final Context context;
        NativeBridge(Context context) { this.context = context; }

        @JavascriptInterface public void fetchMarket(String symbol, int days, String requestId) {
            Executors.newSingleThreadExecutor().execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    String code = symbol.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                    Calendar cal = Calendar.getInstance();
                    String end = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
                    cal.add(Calendar.DAY_OF_YEAR, -Math.max(30, Math.min(days, 730)));
                    String start = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
                    String query = "code:" + code + "~date:gte:" + start + "~date:lte:" + end;
                    String url = "https://finfo-api.vndirect.com.vn/v4/stock_prices?q=" +
                            URLEncoder.encode(query, "UTF-8") + "&size=500&sort=date";
                    result.put("ok", true).put("source", "VNDIRECT").put("payload", new JSONObject(httpGet(url)));
                } catch (Exception e) {
                    try { result.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                sendToJs(requestId, result);
            });
        }

        @JavascriptInterface public void fetchNews(String requestId) {
            Executors.newSingleThreadExecutor().execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    JSONArray items = readRss("https://vnexpress.net/rss/kinh-doanh.rss");
                    result.put("ok", true).put("source", "VnExpress Kinh doanh").put("items", items);
                } catch (Exception e) {
                    try { result.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                sendToJs(requestId, result);
            });
        }

        @JavascriptInterface public void analyze(String body, String requestId) {
            Executors.newSingleThreadExecutor().execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    result.put("ok", true).put("payload", new JSONObject(httpPost(AI_API + "/analyze", body)));
                } catch (Exception e) {
                    try { result.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                sendToJs(requestId, result);
            });
        }

        @JavascriptInterface public void saveAlerts(String json) {
            context.getSharedPreferences("stock_alerts", MODE_PRIVATE).edit().putString("alerts", json).apply();
        }

        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
            });
        }
    }

    private static String httpGet(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000); connection.setReadTimeout(15000);
        connection.setRequestProperty("User-Agent", "AIStockMaster/3.0");
        return readResponse(connection);
    }

    private static String httpPost(String address, String body) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(60000);
        connection.setRequestMethod("POST"); connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
        return readResponse(connection);
    }

    private static String readResponse(HttpURLConnection connection) throws Exception {
        int status = connection.getResponseCode();
        InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder value = new StringBuilder(); String line;
        while ((line = reader.readLine()) != null) value.append(line);
        if (status >= 400) throw new Exception("HTTP " + status + ": " + value);
        return value.toString();
    }

    private static JSONArray readRss(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000); connection.setReadTimeout(15000);
        XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
        parser.setInput(connection.getInputStream(), "UTF-8");
        JSONArray output = new JSONArray(); JSONObject item = null; String tag = "";
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT && output.length() < 20) {
            if (event == XmlPullParser.START_TAG) {
                tag = parser.getName();
                if ("item".equalsIgnoreCase(tag)) item = new JSONObject();
            } else if (event == XmlPullParser.TEXT && item != null) {
                String value = parser.getText().trim();
                if (!value.isEmpty()) {
                    if ("title".equalsIgnoreCase(tag)) item.put("title", value);
                    else if ("link".equalsIgnoreCase(tag)) item.put("link", value);
                    else if ("pubDate".equalsIgnoreCase(tag)) item.put("date", value);
                    else if ("description".equalsIgnoreCase(tag)) item.put("description", value.replaceAll("<[^>]*>", "").trim());
                }
            } else if (event == XmlPullParser.END_TAG && "item".equalsIgnoreCase(parser.getName()) && item != null) {
                output.put(item); item = null;
            }
            event = parser.next();
        }
        return output;
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
