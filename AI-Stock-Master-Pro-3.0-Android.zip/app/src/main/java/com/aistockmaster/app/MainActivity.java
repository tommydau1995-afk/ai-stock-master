package com.aistockmaster.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends ComponentActivity {
    private static final String AI_API = "https://ai-stock-master-api.tommydau1995.chatgpt.site";
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new NativeBridge(this), "NativeApp");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        scheduleAlerts();
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 50);
        }
    }

    private void scheduleAlerts() {
        Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(PriceAlertWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(constraints).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("stock-price-alerts", ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    private void sendToJs(String id, JSONObject payload) {
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.onNativeResult(" + JSONObject.quote(id) + "," + JSONObject.quote(payload.toString()) + ")", null));
    }

    private class NativeBridge {
        private final Context context;
        NativeBridge(Context context) { this.context = context; }

        @JavascriptInterface public void fetchMarket(String symbol, int days, String requestId) {
            Executors.newSingleThreadExecutor().execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    String code = symbol.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                    String url = AI_API + "/market?symbol=" + URLEncoder.encode(code, "UTF-8") +
                            "&days=" + Math.max(30, Math.min(days, 730));
                    JSONObject payload = new JSONObject(httpGet(url));
                    if (payload.has("error")) throw new Exception(payload.optString("error"));
                    result.put("ok", true).put("source", payload.optString("source", "Market API")).put("payload", payload);
                } catch (Exception e) {
                    try { result.put("ok", false).put("error", "Không thể tải dữ liệu. Vui lòng thử lại."); } catch (Exception ignored) {}
                }
                sendToJs(requestId, result);
            });
        }

        @JavascriptInterface public void fetchNews(String requestId) {
            Executors.newSingleThreadExecutor().execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    JSONObject payload = new JSONObject(httpGet(AI_API + "/news"));
                    if (payload.has("error")) throw new Exception(payload.optString("error"));
                    result.put("ok", true).put("source", payload.optString("source", "Tin kinh doanh"))
                            .put("items", payload.optJSONArray("items"));
                } catch (Exception e) {
                    try { result.put("ok", false).put("error", "Không thể tải tin tức. Vui lòng thử lại."); } catch (Exception ignored) {}
                }
                sendToJs(requestId, result);
            });
        }

        @JavascriptInterface public void analyze(String body, String requestId) {
            Executors.newSingleThreadExecutor().execute(() -> {
                JSONObject result = new JSONObject();
                try {
                    result.put("ok", true).put("payload", new JSONObject(httpPost(AI_API + "/analyze", body)));
                } catch (Exception e) {
                    try { result.put("ok", false).put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                sendToJs(requestId, result);
            });
        }

        @JavascriptInterface public void saveAlerts(String json) {
            context.getSharedPreferences("stock_alerts", MODE_PRIVATE).edit().putString("alerts", json).apply();
        }

        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
            });
        }
    }

    private static String httpGet(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(6000); connection.setReadTimeout(10000);
        connection.setRequestProperty("User-Agent", "AIStockMaster/3.0");
        return readResponse(connection);
    }

    private static String httpPost(String address, String body) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(15000); connection.setReadTimeout(60000);
        connection.setRequestMethod("POST"); connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
        return readResponse(connection);
    }

    private static String readResponse(HttpURLConnection connection) throws Exception {
        int status = connection.getResponseCode();
        InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder value = new StringBuilder(); String line;
        while ((line = reader.readLine()) != null) value.append(line);
        if (status >= 400) throw new Exception("HTTP " + status + ": " + value);
        return value.toString();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
