package com.aistockmaster.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class PriceAlertWorker extends Worker {
    public PriceAlertWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        try {
            String raw = getApplicationContext().getSharedPreferences("stock_alerts", Context.MODE_PRIVATE)
                    .getString("alerts", "[]");
            JSONArray alerts = new JSONArray(raw);
            for (int i = 0; i < alerts.length(); i++) {
                JSONObject alert = alerts.getJSONObject(i);
                if (!alert.optBoolean("enabled", true)) continue;
                String symbol = alert.optString("symbol").toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                double target = alert.optDouble("target", 0);
                String type = alert.optString("type", "above");
                double price = latestPrice(symbol);
                boolean hit = "below".equals(type) ? price <= target : price >= target;
                if (hit) notifyAlert(symbol, price, target, type, i);
            }
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    private double latestPrice(String symbol) throws Exception {
        String query = URLEncoder.encode("code:" + symbol, "UTF-8");
        URL url = new URL("https://finfo-api.vndirect.com.vn/v4/stock_prices?q=" + query + "&size=1&sort=date:desc");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(12000);
        BufferedReader reader = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder value = new StringBuilder(); String line;
        while ((line = reader.readLine()) != null) value.append(line);
        JSONObject row = new JSONObject(value.toString()).getJSONArray("data").getJSONObject(0);
        return row.optDouble("close", row.optDouble("adClose", 0));
    }

    private void notifyAlert(String symbol, double price, double target, String type, int id) {
        Context context = getApplicationContext();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "price_alerts";
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(new NotificationChannel(channelId, "Cảnh báo giá", NotificationManager.IMPORTANCE_HIGH));
        }
        String direction = "below".equals(type) ? "giảm xuống dưới" : "tăng lên trên";
        manager.notify((symbol + id).hashCode(), new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(symbol + " đã chạm cảnh báo")
                .setContentText(String.format(Locale.US, "Giá %.2f đã %s %.2f", price, direction, target))
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build());
    }
}
