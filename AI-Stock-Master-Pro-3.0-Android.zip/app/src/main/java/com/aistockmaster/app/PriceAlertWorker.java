package com.aistockmaster.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class PriceAlertWorker extends Worker {
    private static final String API = "https://ai-stock-master-api.tommydau1995.chatgpt.site";
    public PriceAlertWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        try {
            String raw = getApplicationContext().getSharedPreferences("stock_alerts", Context.MODE_PRIVATE).getString("alerts", "[]");
            JSONArray alerts = new JSONArray(raw);
            for (int index = 0; index < alerts.length(); index++) {
                JSONObject alert = alerts.getJSONObject(index);
                if (!alert.optBoolean("enabled", true)) continue;
                String symbol = alert.optString("symbol").toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                String type = alert.optString("type", "above");
                double target = alert.optDouble("target", 0);
                if ("news".equals(type)) {
                    checkNews(symbol, index);
                    continue;
                }
                JSONArray data = marketData(symbol);
                JSONObject latest = data.getJSONObject(data.length() - 1);
                double price = latest.optDouble("close", 0);
                double rsi = rsi(data, 14);
                double[] macd = macd(data);
                double averageVolume = averageVolume(data, 20);
                double volumeRatio = averageVolume > 0 ? latest.optDouble("nmVolume", 0) / averageVolume : 0;
                boolean hit;
                switch (type) {
                    case "below": hit = price <= target; break;
                    case "rsiAbove": hit = rsi >= target; break;
                    case "rsiBelow": hit = rsi <= target; break;
                    case "macdCross": hit = macd[0] > macd[1]; break;
                    case "breakout": hit = price > resistance(data, 20); break;
                    case "volume": hit = volumeRatio >= target; break;
                    default: hit = price >= target;
                }
                if (hit) notifyAlert(symbol, index, String.format(Locale.US,
                        "Giá %.2f · RSI %.1f · KL %.1fx", price, rsi, volumeRatio));
            }
            return Result.success();
        } catch (Exception error) {
            return Result.retry();
        }
    }

    private JSONArray marketData(String symbol) throws Exception {
        JSONObject payload = getJson(API + "/market?symbol=" + URLEncoder.encode(symbol, "UTF-8") + "&days=120");
        return payload.getJSONArray("data");
    }

    private void checkNews(String symbol, int index) throws Exception {
        JSONArray items = getJson(API + "/news?symbol=" + URLEncoder.encode(symbol, "UTF-8")).optJSONArray("items");
        if (items == null || items.length() == 0) return;
        String title = items.getJSONObject(0).optString("title", "");
        String key = "news_" + symbol + "_" + index;
        String previous = getApplicationContext().getSharedPreferences("alert_state", Context.MODE_PRIVATE).getString(key, "");
        if (!previous.isEmpty() && !title.equals(previous)) notifyAlert(symbol, index, title);
        getApplicationContext().getSharedPreferences("alert_state", Context.MODE_PRIVATE).edit().putString(key, title).apply();
    }

    private JSONObject getJson(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(8000); connection.setReadTimeout(12000);
        connection.setRequestProperty("User-Agent", "NhanStockMaster-Alerts/4.0");
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder value = new StringBuilder(); String line;
        while ((line = reader.readLine()) != null) value.append(line);
        return new JSONObject(value.toString());
    }

    private double averageVolume(JSONArray data, int length) {
        double sum = 0; int start = Math.max(0, data.length() - length);
        for (int i = start; i < data.length(); i++) sum += data.optJSONObject(i).optDouble("nmVolume", 0);
        return data.length() > start ? sum / (data.length() - start) : 0;
    }

    private double resistance(JSONArray data, int length) {
        double value = 0; int end = Math.max(0, data.length() - 1);
        for (int i = Math.max(0, end - length); i < end; i++) value = Math.max(value, data.optJSONObject(i).optDouble("high", 0));
        return value;
    }

    private double rsi(JSONArray data, int length) {
        double gains = 0, losses = 0; int start = Math.max(1, data.length() - length);
        for (int i = start; i < data.length(); i++) {
            double change = data.optJSONObject(i).optDouble("close", 0) - data.optJSONObject(i - 1).optDouble("close", 0);
            if (change >= 0) gains += change; else losses -= change;
        }
        return losses == 0 ? 100 : 100 - 100 / (1 + gains / losses);
    }

    private double[] macd(JSONArray data) {
        double e12 = data.optJSONObject(0).optDouble("close", 0), e26 = e12, signal = 0;
        for (int i = 0; i < data.length(); i++) {
            double close = data.optJSONObject(i).optDouble("close", 0);
            e12 = close * (2.0 / 13) + e12 * (11.0 / 13);
            e26 = close * (2.0 / 27) + e26 * (25.0 / 27);
            double line = e12 - e26;
            signal = line * .2 + signal * .8;
        }
        return new double[]{e12 - e26, signal};
    }

    private void notifyAlert(String symbol, int id, String detail) {
        Context context = getApplicationContext();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "stock_intelligence_alerts";
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(new NotificationChannel(channelId, "Cảnh báo chứng khoán", NotificationManager.IMPORTANCE_HIGH));
        }
        manager.notify((symbol + id).hashCode(), new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(symbol + " đã chạm điều kiện")
                .setContentText(detail)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(detail))
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build());
    }
}
