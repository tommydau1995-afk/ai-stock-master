const stocks=[
  {code:"FPT",name:"FPT Corp",price:"128.40",change:"+1.74%",score:88},
  {code:"MBB",name:"MB Bank",price:"25.65",change:"+1.18%",score:84},
  {code:"HPG",name:"Hòa Phát",price:"28.15",change:"+0.90%",score:79},
  {code:"VNM",name:"Vinamilk",price:"67.20",change:"-0.30%",score:68}
];
const modules=[
  ["⌁","Phân tích kỹ thuật","RSI, MACD, MA, hỗ trợ và kháng cự"],
  ["✦","Khuyến nghị AI","Tín hiệu mua, giữ, bán và mức rủi ro"],
  ["⌕","Market Scanner","Lọc cổ phiếu theo điểm số và dòng tiền"],
  ["▤","Tin tức & Sentiment","Tổng hợp tin và đánh giá tâm lý"],
  ["◇","Danh mục đầu tư","Theo dõi lãi lỗ và phân bổ tài sản"],
  ["♙","Portfolio Doctor","Chẩn đoán rủi ro danh mục bằng AI"],
  ["⚑","Alert Center","Cảnh báo giá và tín hiệu kỹ thuật"],
  ["◫","Dashboard thị trường","Độ rộng, thanh khoản, khối ngoại"],
  ["◎","AI Quant Score","Chấm điểm đa yếu tố từ 0 đến 100"],
  ["☵","Trợ lý AI","Giải đáp và phân tích cổ phiếu"]
];
const watchlist=document.querySelector("#watchlist");
watchlist.innerHTML=stocks.map(s=>`<article class="stock" data-code="${s.code}"><div><h4>${s.code}</h4><p>${s.name}</p></div><div class="score">${s.score}</div><div class="price"><b>${s.price}</b><small class="${s.change[0]==="-"?"down":"up"}">${s.change}</small></div></article>`).join("");
const tools=document.querySelector("#tools");
tools.innerHTML=modules.map((m,i)=>`<button class="tool" data-index="${i}"><i>${m[0]}</i><b>${m[1]}</b><small>${m[2]}</small></button>`).join("");
const detail=document.querySelector("#detail");
function openDetail(title,text,tag="AI STOCK MASTER"){
  document.querySelector("#detailTag").textContent=tag;
  document.querySelector("#detailTitle").textContent=title;
  document.querySelector("#detailText").textContent=text;
  document.querySelector("#detailBody").innerHTML=`<div class="demo-card"><b>Trạng thái module</b><small>Sẵn sàng trong bản MVP 2.0 · Dữ liệu minh họa để kiểm thử giao diện.</small></div><div class="demo-card"><b>Quản trị rủi ro</b><small>Thông tin chỉ phục vụ tham khảo, không phải cam kết lợi nhuận hay tư vấn đầu tư cá nhân.</small></div>`;
  detail.classList.remove("hidden");
}
tools.addEventListener("click",e=>{
  const button=e.target.closest(".tool"); if(!button)return;
  const m=modules[Number(button.dataset.index)]; openDetail(m[1],m[2]);
});
watchlist.addEventListener("click",e=>{
  const row=e.target.closest(".stock"); if(!row)return;
  const s=stocks.find(x=>x.code===row.dataset.code);
  openDetail(`${s.code} · Quant Score ${s.score}`,`${s.name} đang có biến động ${s.change}. Điểm số tổng hợp phản ánh động lượng, xu hướng, chất lượng và dòng tiền trong bộ dữ liệu minh họa.`,"PHÂN TÍCH CỔ PHIẾU");
});
document.querySelector("#closeDetail").onclick=()=>detail.classList.add("hidden");
document.querySelector("#refresh").onclick=()=>{
  const value=1286.42+(Math.random()-.5)*3;
  document.querySelector("#indexValue").textContent=value.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
  toast("Đã cập nhật dữ liệu mô phỏng");
};
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{
  document.querySelectorAll("nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");toast(`Đã mở ${b.dataset.tab}`);
});
function toast(message){const t=document.querySelector("#toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
